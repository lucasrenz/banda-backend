import db from '../config/database.js';

// Busca banda do usuário logado
export const getBand = async (req, res) => {
  try {
    const [bands] = await db.query(
      'SELECT * FROM bands WHERE user_id = ? AND is_active = TRUE LIMIT 1',
      [req.user.id]
    );

    if (bands.length === 0) {
      return res.status(404).json({ error: 'Banda não encontrada' });
    }

    const band = bands[0];

    // Busca configurações
    const [settings] = await db.query(
      'SELECT * FROM band_settings WHERE band_id = ?',
      [band.id]
    );

    // Busca eventos
    const [events] = await db.query(
      'SELECT * FROM events WHERE band_id = ? ORDER BY date ASC',
      [band.id]
    );

    // Busca discografia
    const [discography] = await db.query(
      'SELECT * FROM discography WHERE band_id = ? ORDER BY year DESC',
      [band.id]
    );

    // Busca membros
    const [members] = await db.query(
      'SELECT * FROM members WHERE band_id = ? ORDER BY created_at ASC',
      [band.id]
    );

    // Busca galeria
    const [gallery] = await db.query(
      'SELECT * FROM gallery WHERE band_id = ? ORDER BY created_at DESC',
      [band.id]
    );

    // Busca mensagens
    const [messages] = await db.query(
      'SELECT * FROM messages WHERE band_id = ? ORDER BY created_at DESC',
      [band.id]
    );

    res.json({
      band,
      settings: settings[0] || {},
      events,
      discography,
      members,
      gallery,
      messages
    });
  } catch (error) {
    console.error('Erro ao buscar banda:', error);
    res.status(500).json({ error: 'Erro ao buscar dados da banda' });
  }
};

// Busca banda pública (para visitantes)
export const getPublicBand = async (req, res) => {
  try {
    // Busca primeira banda ativa
    const [bands] = await db.query(
      'SELECT * FROM bands WHERE is_active = TRUE ORDER BY created_at ASC LIMIT 1'
    );

    if (bands.length === 0) {
      return res.status(404).json({ error: 'Nenhuma banda encontrada' });
    }

    const band = bands[0];

    // Busca configurações
    const [settings] = await db.query(
      'SELECT * FROM band_settings WHERE band_id = ?',
      [band.id]
    );

    // Busca eventos futuros
    const [events] = await db.query(
      'SELECT * FROM events WHERE band_id = ? AND date >= NOW() ORDER BY date ASC',
      [band.id]
    );

    // Busca discografia
    const [discography] = await db.query(
      'SELECT * FROM discography WHERE band_id = ? ORDER BY year DESC',
      [band.id]
    );

    // Busca membros
    const [members] = await db.query(
      'SELECT * FROM members WHERE band_id = ? ORDER BY created_at ASC',
      [band.id]
    );

    // Busca galeria
    const [gallery] = await db.query(
      'SELECT * FROM gallery WHERE band_id = ? ORDER BY created_at DESC',
      [band.id]
    );

    res.json({
      band,
      settings: settings[0] || {},
      events,
      discography,
      members,
      gallery
    });
  } catch (error) {
    console.error('Erro ao buscar banda pública:', error);
    res.status(500).json({ error: 'Erro ao buscar dados da banda' });
  }
};

// Atualiza configurações da banda
export const updateBandSettings = async (req, res) => {
  try {
    const { field, value } = req.body;
    
    // Busca banda do usuário
    const [bands] = await db.query(
      'SELECT id FROM bands WHERE user_id = ? LIMIT 1',
      [req.user.id]
    );

    if (bands.length === 0) {
      return res.status(404).json({ error: 'Banda não encontrada' });
    }

    const bandId = bands[0].id;

    // Atualiza campo específico
    const allowedFields = ['band_data', 'page_settings', 'theme_settings', 'page_content'];
    
    if (!allowedFields.includes(field)) {
      return res.status(400).json({ error: 'Campo inválido' });
    }

    await db.query(
      `UPDATE band_settings SET ${field} = ? WHERE band_id = ?`,
      [JSON.stringify(value), bandId]
    );

    res.json({ message: 'Configurações atualizadas com sucesso' });
  } catch (error) {
    console.error('Erro ao atualizar configurações:', error);
    res.status(500).json({ error: 'Erro ao atualizar configurações' });
  }
};

