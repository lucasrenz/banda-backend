import express from 'express';
import { register, login, getUser } from '../controllers/authController.js';
import { getBand, getPublicBand, updateBandSettings } from '../controllers/bandController.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// ============================================
// ROTAS PÚBLICAS
// ============================================

// Autenticação
router.post('/auth/register', register);
router.post('/auth/login', login);

// Dados públicos da banda
router.get('/public/band', getPublicBand);

// ============================================
// ROTAS PROTEGIDAS (requerem autenticação)
// ============================================

// Usuário
router.get('/user', authenticateToken, getUser);

// Banda
router.get('/band', authenticateToken, getBand);
router.put('/band/settings', authenticateToken, updateBandSettings);

// Eventos
router.post('/events', authenticateToken, async (req, res) => {
  try {
    const { title, date, location, description, ticket_link, image_url } = req.body;
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query(
      'INSERT INTO events (band_id, title, date, location, description, ticket_link, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [bandId, title, date, location, description, ticket_link, image_url]
    );
    
    res.status(201).json({ message: 'Evento criado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao criar evento' });
  }
});

router.put('/events/:id', authenticateToken, async (req, res) => {
  try {
    const { title, date, location, description, ticket_link, image_url } = req.body;
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query(
      'UPDATE events SET title = ?, date = ?, location = ?, description = ?, ticket_link = ?, image_url = ? WHERE id = ? AND band_id = ?',
      [title, date, location, description, ticket_link, image_url, req.params.id, bandId]
    );
    
    res.json({ message: 'Evento atualizado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar evento' });
  }
});

router.delete('/events/:id', authenticateToken, async (req, res) => {
  try {
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query('DELETE FROM events WHERE id = ? AND band_id = ?', [req.params.id, bandId]);
    res.json({ message: 'Evento removido com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao remover evento' });
  }
});

// Discografia
router.post('/discography', authenticateToken, async (req, res) => {
  try {
    const { title, year, cover_url, description, spotify_link, apple_music_link, youtube_link } = req.body;
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query(
      'INSERT INTO discography (band_id, title, year, cover_url, description, spotify_link, apple_music_link, youtube_link) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [bandId, title, year, cover_url, description, spotify_link, apple_music_link, youtube_link]
    );
    
    res.status(201).json({ message: 'Álbum criado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao criar álbum' });
  }
});

router.put('/discography/:id', authenticateToken, async (req, res) => {
  try {
    const { title, year, cover_url, description, spotify_link, apple_music_link, youtube_link } = req.body;
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query(
      'UPDATE discography SET title = ?, year = ?, cover_url = ?, description = ?, spotify_link = ?, apple_music_link = ?, youtube_link = ? WHERE id = ? AND band_id = ?',
      [title, year, cover_url, description, spotify_link, apple_music_link, youtube_link, req.params.id, bandId]
    );
    
    res.json({ message: 'Álbum atualizado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar álbum' });
  }
});

router.delete('/discography/:id', authenticateToken, async (req, res) => {
  try {
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query('DELETE FROM discography WHERE id = ? AND band_id = ?', [req.params.id, bandId]);
    res.json({ message: 'Álbum removido com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao remover álbum' });
  }
});

// Membros
router.post('/members', authenticateToken, async (req, res) => {
  try {
    const { name, role, bio, photo_url, social_links } = req.body;
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query(
      'INSERT INTO members (band_id, name, role, bio, photo_url, social_links) VALUES (?, ?, ?, ?, ?, ?)',
      [bandId, name, role, bio, photo_url, JSON.stringify(social_links || {})]
    );
    
    res.status(201).json({ message: 'Membro adicionado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao adicionar membro' });
  }
});

router.put('/members/:id', authenticateToken, async (req, res) => {
  try {
    const { name, role, bio, photo_url, social_links } = req.body;
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query(
      'UPDATE members SET name = ?, role = ?, bio = ?, photo_url = ?, social_links = ? WHERE id = ? AND band_id = ?',
      [name, role, bio, photo_url, JSON.stringify(social_links || {}), req.params.id, bandId]
    );
    
    res.json({ message: 'Membro atualizado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar membro' });
  }
});

router.delete('/members/:id', authenticateToken, async (req, res) => {
  try {
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query('DELETE FROM members WHERE id = ? AND band_id = ?', [req.params.id, bandId]);
    res.json({ message: 'Membro removido com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao remover membro' });
  }
});

// Galeria
router.post('/gallery', authenticateToken, async (req, res) => {
  try {
    const { image_url, caption } = req.body;
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query(
      'INSERT INTO gallery (band_id, image_url, caption) VALUES (?, ?, ?)',
      [bandId, image_url, caption]
    );
    
    res.status(201).json({ message: 'Foto adicionada com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao adicionar foto' });
  }
});

router.delete('/gallery/:id', authenticateToken, async (req, res) => {
  try {
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query('DELETE FROM gallery WHERE id = ? AND band_id = ?', [req.params.id, bandId]);
    res.json({ message: 'Foto removida com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao remover foto' });
  }
});

// Mensagens
router.post('/messages', async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;
    
    // Busca primeira banda ativa
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE is_active = TRUE LIMIT 1');
    if (bands.length === 0) {
      return res.status(404).json({ error: 'Banda não encontrada' });
    }
    const bandId = bands[0].id;
    
    await req.app.locals.db.query(
      'INSERT INTO messages (band_id, name, email, subject, message) VALUES (?, ?, ?, ?, ?)',
      [bandId, name, email, subject, message]
    );
    
    res.status(201).json({ message: 'Mensagem enviada com sucesso' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao enviar mensagem' });
  }
});

router.put('/messages/:id/read', authenticateToken, async (req, res) => {
  try {
    const [bands] = await req.app.locals.db.query('SELECT id FROM bands WHERE user_id = ? LIMIT 1', [req.user.id]);
    const bandId = bands[0].id;
    
    await req.app.locals.db.query(
      'UPDATE messages SET is_read = TRUE WHERE id = ? AND band_id = ?',
      [req.params.id, bandId]
    );
    
    res.json({ message: 'Mensagem marcada como lida' });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao atualizar mensagem' });
  }
});

export default router;

